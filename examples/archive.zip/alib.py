def libfunc(text):
    print('got text:', text)