def setup(project):
    project.params["test123"] = "456"
    return project
