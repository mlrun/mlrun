def blibfunc(text):
    print('blib got text:', text)