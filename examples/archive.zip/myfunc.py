import alib
import mlrun

def handler(context: mlrun.MLClientCtx, p1, p2=3, p3=4):
    print(f"Run: {context.name} (uid={context.uid})")
    print("my line")
    alib.libfunc('some text')
    context.log_result("accuracy", p2*2)
    context.log_result("loss", p3*3)
