import blib
import mlrun

def my_handler(context: mlrun.MLClientCtx, p1, p2=3, p3=4):
    print(f"Run: {context.name} (uid={context.uid})")
    print("my line")
    blib.blibfunc('some text')
    context.log_result("accuracy", p2*2)
    context.log_result("loss", p3*3)


if __name__ == "__main__":
    context = mlrun.get_or_create_ctx("test")
    p1 = context.get_param("p1", 1)
    my_handler(context, p1)
