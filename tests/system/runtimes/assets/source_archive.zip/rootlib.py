def myfunc():
    print("in myfunc()")
